
           #' second dataset for HW 3
           #'
           #' @author Zack W. Almquist \email{almquist@umn.edu}
           #' @references \url{http://users.stat.umn.edu/~almquist/3811_examples/gapminder2007ex.csv}
           "d2" 