library(testthat)
library(LiXinfengTools)

test_check("LiXinfengTools")
